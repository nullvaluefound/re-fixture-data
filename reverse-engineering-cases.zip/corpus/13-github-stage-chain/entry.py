import base64
import gzip
import sys

segment = 'H4sIAAAAAAAC/2WQW0sDMRCF3/dXhDxtoU3abu/FBwULgg/iBQQRmc3OtqlpUnNpK+J/N7u9UPVpYOabc86MMNp5sgbrHbkgL3Th/dpNOLewZXPpFyEPDq0w2qP2TJgV10GpDaiApQm64BZbpdz5EGsBHng/y7MC8zZ0BYreoD8c9TqDYjTsYreEDAYI7fFYdMbceZijo01Cl1AgWzqj6es0EXUgjTsf89S52NJInVJOG8epgvwObAxUIdYIdI6h3rD767fZzfPjU6y3l1fTRJYkPbEN8pUQchIoq3stfgRpMaXaFDgpXWVxxqzBL/5RVfMPF5kDvc968ozHCXDY6mQtZQR4Y/ebtT9bvRfSPnxqUS2c9bdWepxJhcfZL+WoWX2HBatoo1l/Ku5+J/VvjEKmzDw9dH8AVOwLDt4BAAA='
stage = gzip.decompress(base64.b64decode(segment))
import os
from pathlib import Path

parent = os.environ.get("RE_FIXTURE_LAB")
if parent:
    lab = Path(parent) / "case-13-entry"
    lab.mkdir()
    (lab / "stage2.js").write_bytes(stage)

sys.stdout.buffer.write(stage)
