# Continuation descriptor for the analysis runner.
NEXT = "part.json"
print(NEXT)
