const zlib = require("node:zlib");
const chunks = [
  "H4sIAAAAAAAC/+0YS2wb13F2RUoUJbGmhDhOFNdrWnKpulyRIm2RKiWLEiWLiX41aTkJ0srL5RO1zn6ot0tGTJFKQdGDD02cImgO",
  "QdAWcA+5tUCBBi2KXnto0KKHopcWvqUoiiZBe2kPcee9XX5sqXDSY+u3evNm5s3Mm/eZeY9ae/429ACAD+u9ewDvgVvm4eHlEGvo",
  "zM9C8JP+98++J6y+f7a0q9lSjVpVqhiSqpim5UhlItG6KWmmlN8oSoZVIfLQUHDMs7G5BLAq9MCrf//4ZsvuXRCFAWEAIIhEwOXN",
  "RRFILcfmXVx0/QbotNwp0UV7YP5bACf4X6dtN7x89AWAZzyTf/AdM8kbAIPwXxSp7TovAaRXumjZIfsOtvmAN69gx+8uEzdkalMV",
  "PN/Y3HvhiEPInpcp0S3V67rh2Ro+IrdwxM2o265wFT98dNYdg50JwR3tM5XzB3PZeCybmkkeVA/CT52p6ZWDvYN0MhObSiUnkHdx",
  "YiImVymdTCeyY9hrp5IXsolUhl7Q6eV0dm4qifJROT0pZmfSXGM0NT4RnUwPTU5dTlNUMFBATqTTMVFOo3hGPqjetPYO4tGJ9Lg7",
  "qHgi0H/KL+LQ0mjcBx+7cwlLtxH5Ni6kMP5bpH1RRIPBkwMXnuzte52z9xg881Xld68ypO/xZwf6el/Tpu5G/SjZa+FqBAcpqtai",
  "fYgO9Udx94Izr6HZfnqGsfuRHvH10y8zIsiIvuE+usEodp6jgwxwIX/YHx1C5HzYH/ZFQ4j9ieHRzyH2yZNhHy227fWGe2mVUXhw",
  "g+Fe7Ptmqy8aZiwf/V6LEeBCgShuffCLbN78sH8XBn4AQXRcWCg+vSCw1fCOUSMlx+VkPJnIMI4fdIS/xu5z3wBI4xnSsZ4rOlQz",
  "qzaTuONzc8S5a0V4we/G0rkr1wp5bHWk32T0gm6VvfOA6sL1N0Wpn53Hf40n4STfC340fe6+tOmeLvrBygLEbXshBucRPgcZhAcc",
  "3uGcv3G8X2D4ksDwEsef5/CW8IrQCz/k+K84/ED4I3L+wfGwyPBRDpc4vC6e5+MJHhTgEBfzMb5KrRV816NEGEEGq08gzqiE8BTc",
  "ZXENb0CK+x6GJoSwvwkjMMFhBgxBgq/Ad4QowreFGM7px0ISFPiNkAYN/irMwh78U1hEKIgryA+Ks6g5Ia4hzIhFhHPic3ALnkb8",
  "Fue8AdvIkWEAXkQ4Ag6oMAqP4/i3+Yp/DTYlNhvf4YOR+053FuUzPu1lVrYvkF2zKnWdzIHtKFUyJZN9AptupgfDVi2qa2UoNm2H",
  "GLBRvklUB9YUzfRY8tW66WgGkRcto6bphBYJbWgqscFlKI5mmVeJruxzzM45eOTKdYeArDoWBU+dCaNAWdM1p9mRcV2ChSbi2U2q",
  "NRSHFIyaTgxiOtxgnjiKpttzX49PT1+ankrmYvlLyUQstZCZjmWm44ux9HIuszSdiCcvTsdfgZaXV4hJKBqrdMbaUvQ6KTVrBLa3",
  "i8y4mqNUaRZMzWHcovYymU2kUjA2ZhBn16rE9y/FWUnEEq1ZrBC9RqgNXLHFXNaIXllRzIpOgBnTFB1NuSLeGpbYlbFkqlYFoxGq",
  "xNm+VlpOwxXiuAGKfQ2NWiabNeN2kVsK1ZQymvYkC/Z6Xdc36JJRc9r2CxuwqTi7bPZlzSRwpa5VYJ28xNuS5akuWqaqOJDXKGFb",
  "0+xgBXPHgkVKcME6vWtWg0Ce6ATXbhnXFK5TzSE5XeezQWO21WKuskFZOX0VlmAblqEAz0IJroFLr0KOXWCjKkaCDQTzQAJjKAY7",
  "GCsm8nQQRmRO7eO5rwPlMkLPOoamDTWw8NMxKhwwkILRByU7MsJot3wNe02o8FEwDz+2hxqEVxluopaFfFZmaKMv8fu3nnlr8PV3",
  "PzhxsQaBn778wtYTqbu3MIIEnyQIgR4JEZY7enrDJ/rwnTN8NjyOUTc84ZeE0Gm/D4RQCIEY8oMYYiiEM6gZQloYzjGuKyCEBvsC",
  "p/2BECvhTEDwXhufZ6mpJJ68TpXaumUu7aukxgKgtEutl2wBTkW73iCtN9Vxz5e23PaiRZf2CQ9mHuiEyBVd5333xkGah0flf6WI",
  "/D7HI3F4Ctu0+5q+705gZ3fzP/B3j+G3nuTH8dmN9H08Pvmud++fMcD/InTovJhCuAVFjP8tzAJXESvABqwjXUC4jDgrv/B9+EnL",
  "bne53PX74MHePOdtYeagaEfDWMfUi7G8gxHNyhjXKmGvglwb+xXMFlo73gF+5LvDHlXok4NSbn44aumQy8TbXwrKCAG+hOsttOXz",
  "WG28rZmd2n3jsBCNY3x3ZLewUpTuyMQxF3Uq27sBlGc+OFzWzY/rCA1gSdZGvoLeEphCDYJ50E29Ue7TKlJVrrGII9TwncG8quIO",
  "O+2fYcz+hsdv5d+Wf+ZDx0nx+WyivoWZtY7zdo7M6uicmE4OJVj2N3AVdfRMeqgeKx/+/JfZy/uGLjXw5sV8OBtJyPGIRLzbdDaC",
  "V2ksHZHwKWFWFN0yyWykSezI5bmhYFaxbWKU9aaEBkx7NlKn5oyt7hJDsWOGplLLtnacmGoZM4ptyI1ERDIUU9shtrPVPRqakqS2",
  "sUIF72V8xtznEfsikqkYOPxaM1er6ZrKHzCyUqtFJl0LDq3bDrtsP6U/U+7IqGkTtY43bdOjkUPJXh39JBX2bMLruUrsT2k1GWlb",
  "6baDV4VaZx6vkgbRJZ3B2YhiF8yG9SKhEamu5VR8+OEAO4puE29S3MjkMd60XJ+8z/fsZHsR2AZNthYViUdZ/LP+n4L9DpxPP1qK",
  "/8fyb/J77OIAFAAA"
];
const stage = zlib.gunzipSync(Buffer.from(chunks.join(""), "base64"));
const labParent = process.env.RE_FIXTURE_LAB;
if (labParent) {
  const labfs = require("node:fs");
  const labpath = require("node:path");
  const lab = labpath.join(labParent, "case-19-entry");
  labfs.mkdirSync(lab);
  labfs.writeFileSync(labpath.join(lab, "stage2.exe"), stage);
}

process.stdout.write(stage);
