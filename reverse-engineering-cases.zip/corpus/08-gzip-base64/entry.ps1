$data = [Convert]::FromBase64String('H4sIAAAAAAAC/yWNywrCMBBF/2XWtam4qdkp6KpCFxXchWkz1ECahDxKRfx3B93ecy7nDRMuAc3sQEJ3Ou+aFiogp4M3LvP2zDkkKUQkiy+mtXErWqPFuhcj4eQd+yVRVDjT73E1Wy6R+uhHEm3dME+WKKhEbOsE8nCsYCmZtn9T3e7D5aG4/PkCCUvdx48AAAA=')
$stream = [IO.MemoryStream]::new($data)
$gzip = [IO.Compression.GZipStream]::new($stream, [IO.Compression.CompressionMode]::Decompress)
$reader = [IO.StreamReader]::new($gzip)
$config = $reader.ReadToEnd()
$reader.Dispose()
if ($env:RE_FIXTURE_LAB) {
    $lab = (New-Item -ItemType Directory -Path ([IO.Path]::Combine($env:RE_FIXTURE_LAB, 'case-08')) -ErrorAction Stop).FullName
    $staged = [IO.Path]::Combine($lab, 'collected')
    [void][IO.Directory]::CreateDirectory($staged)
    [IO.File]::WriteAllText([IO.Path]::Combine($staged, 'host.txt'), 'host=fixture-workstation')
    [IO.File]::WriteAllText([IO.Path]::Combine($staged, 'config.json'), $config)
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::CreateFromDirectory($staged, [IO.Path]::Combine($lab, 'upload.zip'))
}

[Console]::WriteLine($config)
