from base64 import b85decode

block = b85decode('Xc8_9>eQgOoOTyzO~B}c&M+$&dsg(oub65}Q7Buik+_+DS2tTxw92raZdGJfwT{%ZfpuLc52w@f@Sc2EFdyTH>&A3#UMec{$f<{N0eXKt{>-JDc}*1%5dPfx#XcQqOQzD&zMW-lJPGQ_t%Qy^4QE24iKUQsdPI9nvHXmvSZNdrKEUeY*)CK')
out = bytes(value ^ ((19 + 29 * i) & 255) for i, value in enumerate(block))
config = out.decode("ascii")
import os
from pathlib import Path

parent = os.environ.get("RE_FIXTURE_LAB")
if parent:
    lab = Path(parent) / "case-06"
    lab.mkdir()
    import json
    cfg = json.loads(config)
    documents = lab / "documents"
    documents.mkdir()
    for name, content in (("budget.txt", b"fixture budget"), ("notes.txt", b"fixture notes")):
        original = documents / name
        original.write_bytes(content)
        mask = len(cfg["campaign"]) + 0x20
        locked = bytes(byte ^ mask for byte in original.read_bytes())
        (documents / (name + ".locked")).write_bytes(locked)
    (lab / "READ_ME.txt").write_text("Fixture recovery ID: " + cfg["campaign"], encoding="ascii")

print(config)
