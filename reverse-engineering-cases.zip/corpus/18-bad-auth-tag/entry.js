const crypto = require("node:crypto");
const key = Buffer.from("995794770ab435681bb204356ee613b659205d9ba5e7a036ca4819c19a7ed107", "hex");
const nonce = Buffer.from("5YXUstfXZ4eNZJlr", "base64");
const data = Buffer.from("yrQ+VdQ/IDTBr+v2DPNHjAZnFDx7t2xeDCNL41S9km6G8i/GVH2wiIyWuwnVL8DeNID+zJ7SBxh0yu3YuOmXQgzaOdYGkW+fyZZ+1Ac0HUgOcSSBtGjoYlBOTjPFc1sIKCUE1ofmhAoZflZyi0aEochBQfcH4LwzDLE6YF1U+M1L4AErv7UDA+gFPQc26Z84", "base64");
const tag = Buffer.from("s5LAc0eKOmPM1kUgqtbmHQ==", "base64");
let config;
try {
  const decipher = crypto.createDecipheriv("aes-256-gcm", key, nonce);
  decipher.setAAD(Buffer.from("fixture:18", "ascii"));
  decipher.setAuthTag(tag);
  const out = Buffer.concat([decipher.update(data), decipher.final()]);
  config = out.toString("utf8");
} catch (error) {
  console.error("AUTH_TAG_INVALID");
  process.exitCode = 2;
}
if (config !== undefined) {
const labParent = process.env.RE_FIXTURE_LAB;
if (labParent) {
  const labfs = require("node:fs");
  const labpath = require("node:path");
  const lab = labpath.join(labParent, "case-18");
  labfs.mkdirSync(lab);
  const cfg = JSON.parse(config);
  labfs.writeFileSync(labpath.join(lab, "active-config.json"), config);
  const lock = labfs.openSync(labpath.join(lab, "session.lock"), "wx");
  try { labfs.writeFileSync(lock, cfg.mutex); } finally { labfs.closeSync(lock); }
}

  console.log(config);
}
