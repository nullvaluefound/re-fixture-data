const crypto = require("node:crypto");
const key = Buffer.from("71909bac327126614d541f64366539e8a44647a0bf689dbe4bbd69f433ed701b", "hex");
const nonce = Buffer.from("zGx4czeFdkcX9vSB", "base64");
const data = Buffer.from("yLq1Uynkwp2bTlM7OpafrNsva9DLAFs8SdbQyF1/2952wmggyV/KPSPKaTIQH8bNFj2bVgTIerbD/EDR4RwNtXa5pDQzrVbukPuHdJbT4m74DHxQW3MQml+T2XmORETXb9lI1YMCUansLeqBN1bIRY3js17vqWBDQlByTHzF9SmhDuboaw2CaPlA0hqzJ47y", "base64");
const tag = Buffer.from("ydLQ/gS05JmjAUZvX/JdlA==", "base64");
let config;
try {
  const decipher = crypto.createDecipheriv("aes-256-gcm", key, nonce);
  decipher.setAAD(Buffer.from("fixture:10", "ascii"));
  decipher.setAuthTag(tag);
  const out = Buffer.concat([decipher.update(data), decipher.final()]);
  config = out.toString("utf8");
} catch (error) {
  console.error("AUTH_TAG_INVALID");
  process.exitCode = 2;
}
if (config !== undefined) {
const labParent = process.env.RE_FIXTURE_LAB;
if (labParent) {
  const labfs = require("node:fs");
  const labpath = require("node:path");
  const lab = labpath.join(labParent, "case-10");
  labfs.mkdirSync(lab);
  const cfg = JSON.parse(config);
  labfs.writeFileSync(labpath.join(lab, "active-config.json"), config);
  const lock = labfs.openSync(labpath.join(lab, "session.lock"), "wx");
  try { labfs.writeFileSync(lock, cfg.mutex); } finally { labfs.closeSync(lock); }
}

  console.log(config);
}
