# Example endpoint in a comment: https://decoy.invalid/never-selected
config = '{"campaign":"LAB-01","endpoint":"https://relay-01.invalid/v1/beacon","user_agent":"FixtureProbe/1.0","sleep_seconds":18,"mutex":"LAB_MUTEX_01"}'
import os
from pathlib import Path

parent = os.environ.get("RE_FIXTURE_LAB")
if parent:
    lab = Path(parent) / "case-01"
    lab.mkdir()
    import json
    cfg = json.loads(config)
    source = lab / "vault.json"
    source.write_text('{"user":"fixture-user","token":"LAB-TOKEN-01"}', encoding="ascii")
    entry = json.loads(source.read_text(encoding="ascii"))
    packet = {"destination": cfg["endpoint"], "record": entry}
    (lab / "outbox.json").write_text(json.dumps(packet), encoding="ascii")

print(config)
