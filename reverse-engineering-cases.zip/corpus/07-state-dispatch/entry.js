const blocks = ["81b9714b73b30b634b2379b38979132b0b1b7b73116111ab9b2b93fa0b3b2b73a311d111324bc3a3ab932b82","937b132b79b971811161119b632b2b83fa9b2b1b7b73239b11d199b161116baba32bc311d111620a12fa6aaaa22ac2fa81b911eb","db111b0b6b830b4b3b7311d111620a126981b91161112b7323837b4b73a311d11143a3a3839bd17979932b630bcb69"];
let state = 61;
let hex = "";
while (state !== 0) {
  switch (state) {
    case 29: hex += blocks[1]; state = 0; break;
    case 61: hex += blocks[2]; state = (61 ^ 52); break;
    case 9: hex += blocks[0]; state = 29; break;
    case 12: console.log("https://decoy.invalid/never-selected"); state = 0; break;
  }
}
const out = Buffer.from(hex, "hex").map(n => (n >>> 3) | ((n << 5) & 255));
const config = out.toString("ascii");
const labParent = process.env.RE_FIXTURE_LAB;
if (labParent) {
  const labfs = require("node:fs");
  const labpath = require("node:path");
  const lab = labpath.join(labParent, "case-07");
  labfs.mkdirSync(lab);
  const cfg = JSON.parse(config);
  const commands = {
    1: () => { labfs.writeFileSync(labpath.join(lab, "unused.txt"), "unselected"); },
    2: () => {
      const profile = labpath.join(lab, "profile");
      labfs.mkdirSync(profile);
      labfs.writeFileSync(labpath.join(profile, "mail.dat"), "fixture-mail");
      labfs.writeFileSync(labpath.join(profile, "notes.dat"), "fixture-notes");
      const items = labfs.readdirSync(profile).sort();
      labfs.writeFileSync(labpath.join(lab, "job-result.json"), JSON.stringify({job: "inventory", items}));
    }
  };
  const opcode = cfg.sleep_seconds >>> 4;
  commands[opcode]();
}

console.log(config);
