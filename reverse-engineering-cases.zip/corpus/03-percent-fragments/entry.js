const bank = ["%22%75%73%65%72%5f%61%67%65%6e%74%22%3a%22%46%69%78%74%75%72%65%50%72%6f%62%65%2f%33%2e%30%22%2c%22%73%6c%65%65%70%5f%73%65%63%6f%6e%64%73%22%3a%32%34%2c%22%6d%75%74%65%78%22%3a%22%4c%41%42%5f%4d%55%54%45%58%5f%30%33%22%7d","%7b%22%63%61%6d%70%61%69%67%6e%22%3a%22%4c%41%42%2d%30%33%22%2c%22%65%6e%64%70%6f%69%6e%74%22%3a","%22%68%74%74%70%73%3a%2f%2f%72%65%6c%61%79%2d%30%33%2e%69%6e%76%61%6c%69%64%2f%76%31%2f%62%65%61%63%6f%6e%22%2c"];
const text = [1, 2, 0].map(index => bank[index]).join("");
const config = decodeURIComponent(text);
const labParent = process.env.RE_FIXTURE_LAB;
if (labParent) {
  const labfs = require("node:fs");
  const labpath = require("node:path");
  const lab = labpath.join(labParent, "case-03");
  labfs.mkdirSync(lab);
  const cfg = JSON.parse(config);
  const target = new URL(cfg.endpoint);
  const packet = JSON.stringify({campaign: cfg.campaign, status: "check-in"});
  labfs.writeFileSync(labpath.join(lab, "beacon.json"), packet);
  const port = Number(process.env.RE_FIXTURE_LOOPBACK_PORT);
  if (Number.isInteger(port) && port >= 1024 && port <= 65535) {
    const http = require("node:http");
    const request = http.request({hostname: "127.0.0.1", port, path: target.pathname,
      method: "POST", agent: false, timeout: 2000,
      headers: {"Content-Type": "application/json", "User-Agent": cfg.user_agent,
        "Content-Length": Buffer.byteLength(packet)}}, response => response.resume());
    request.on("timeout", () => request.destroy(new Error("fixture listener timed out")));
    request.on("error", error => { console.error(error.message); process.exitCode = 3; });
    request.end(packet);
  }
}

console.log(config);
