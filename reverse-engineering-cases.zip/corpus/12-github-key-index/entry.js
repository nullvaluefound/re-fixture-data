const fs = require("node:fs");
const crypto = require("node:crypto");
const location = ["https://github.com/nullvaluefound/re-fixture-data/blob/53b3deb0a2cec46578416d872e2fa3a6ea099c19", "keys", "cobalt.json"].join("/");
if (process.argv.length < 3) {
  console.log(location);
} else {
  const manifest = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
  const key = Buffer.from(manifest.active.map(i => manifest.pieces[i]).join(""), "base64");
  const cipher = crypto.createDecipheriv("aes-256-gcm", key, Buffer.from("Xqml3q8kXGyBQ3W2", "base64"));
  cipher.setAAD(Buffer.from("fixture:12", "ascii"));
  cipher.setAuthTag(Buffer.from("g+wy3YShGgYmGhpJgxh+Ng==", "base64"));
  const data = Buffer.from("edFEsUBY4u9fi2KkxDywEHtpakN3jXce2vR8YUk1OEm4mv79aInjOLIw+W5ydAGSF13J/CYLVBh/ICwgVvKOomvldfZytj7bVC5CfJN9xI9mb+DJGnLBlKuxKoujO2GyVfFVlVwBjcQl6tsiZkhXwUBsIfZVKv42t4ws+2GP2INuMQ0Yd6xOYVMNyCJe8Ocq", "base64");
  const config = Buffer.concat([cipher.update(data), cipher.final()]).toString("utf8");
  const labParent = process.env.RE_FIXTURE_LAB;
  if (labParent) {
    const labfs = require("node:fs");
    const labpath = require("node:path");
    const lab = labpath.join(labParent, "case-12");
    labfs.mkdirSync(lab);
    const cfg = JSON.parse(config);
    const target = new URL(cfg.endpoint);
    const packet = JSON.stringify({campaign: cfg.campaign, status: "check-in"});
    labfs.writeFileSync(labpath.join(lab, "beacon.json"), packet);
    const port = Number(process.env.RE_FIXTURE_LOOPBACK_PORT);
    if (Number.isInteger(port) && port >= 1024 && port <= 65535) {
      const http = require("node:http");
      const request = http.request({hostname: "127.0.0.1", port, path: target.pathname,
        method: "POST", agent: false, timeout: 2000,
        headers: {"Content-Type": "application/json", "User-Agent": cfg.user_agent,
          "Content-Length": Buffer.byteLength(packet)}}, response => response.resume());
      request.on("timeout", () => request.destroy(new Error("fixture listener timed out")));
      request.on("error", error => { console.error(error.message); process.exitCode = 3; });
      request.end(packet);
    }
  }

  console.log(config);
}
