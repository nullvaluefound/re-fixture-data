$blob = 'ewAiAGMAYQBtAHAAYQBpAGcAbgAiADoAIgBMAEEAQgAtADAAMgAiACwAIgBlAG4AZABwAG8AaQBuAHQAIgA6ACIAaAB0AHQAcABzADoALwAvAHIAZQBsAGEAeQAtADAAMgAuAGkAbgB2AGEAbABpAGQALwB2ADEALwBiAGUAYQBjAG8AbgAiACwAIgB1AHMAZQByAF8AYQBnAGUAbgB0ACIAOgAiAEYAaQB4AHQAdQByAGUAUAByAG8AYgBlAC8AMgAuADAAIgAsACIAcwBsAGUAZQBwAF8AcwBlAGMAbwBuAGQAcwAiADoAMgAxACwAIgBtAHUAdABlAHgAIgA6ACIATABBAEIAXwBNAFUAVABFAFgAXwAwADIAIgB9AA=='
$config = [Text.Encoding]::Unicode.GetString([Convert]::FromBase64String($blob))
if ($env:RE_FIXTURE_LAB) {
    $lab = (New-Item -ItemType Directory -Path ([IO.Path]::Combine($env:RE_FIXTURE_LAB, 'case-02')) -ErrorAction Stop).FullName
    $cfg = ConvertFrom-Json -InputObject $config
    $manifest = [ordered]@{ task = $cfg.mutex; interval_seconds = $cfg.sleep_seconds; action = 'fixture-check-in' }
    [IO.File]::WriteAllText([IO.Path]::Combine($lab, 'scheduled-task.json'), ($manifest | ConvertTo-Json -Compress))
}

[Console]::WriteLine($config)
