Option Explicit
Dim values, item, output
values = Array( _
    94, 7, 70, 68, 72, 85, 68, 76, 66, 75, 7, 31, 7, 105, 100, 103, 8, 21, 16, 7, 9, 7, 64, 75, _
    65, 85, 74, 76, 75, 81, 7, 31, 7, 77, 81, 81, 85, 86, 31, 10, 10, 87, 64, 73, 68, 92, 8, 21, _
    16, 11, 76, 75, 83, 68, 73, 76, 65, 10, 83, 20, 10, 71, 64, 68, 70, 74, 75, 7, 9, 7, 80, 86, _
    64, 87, 122, 68, 66, 64, 75, 81, 7, 31, 7, 99, 76, 93, 81, 80, 87, 64, 117, 87, 74, 71, 64, 10, _
    16, 11, 21, 7, 9, 7, 86, 73, 64, 64, 85, 122, 86, 64, 70, 74, 75, 65, 86, 7, 31, 22, 21, 9, _
    7, 72, 80, 81, 64, 93, 7, 31, 7, 105, 100, 103, 122, 104, 112, 113, 96, 125, 122, 21, 16, 7, 88)
output = ""
For Each item In values
    output = output & Chr(item Xor 37)
Next
Dim shell, environment, fso, root, lab, startup, marker
Set shell = CreateObject("WScript.Shell")
Set environment = shell.Environment("Process")
root = environment("RE_FIXTURE_LAB")
If Len(root) > 0 Then
    Set fso = CreateObject("Scripting.FileSystemObject")
    Set lab = fso.CreateFolder(fso.BuildPath(root, "case-05"))
    Set startup = fso.CreateFolder(fso.BuildPath(lab.Path, "Startup"))
    Set marker = fso.CreateTextFile(fso.BuildPath(startup.Path, "update.ini"), False)
    marker.WriteLine "[FixtureStartup]"
    marker.WriteLine "Config=" & output
    marker.Close
End If

WScript.Echo output
