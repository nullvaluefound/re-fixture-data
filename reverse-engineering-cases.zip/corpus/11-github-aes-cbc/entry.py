import argparse
import base64
from pathlib import Path
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

key_locator = 'https://raw.githubusercontent.com/nullvaluefound/re-fixture-data/53b3deb0a2cec46578416d872e2fa3a6ea099c19/keys/amber.txt'
iv = bytes.fromhex("efec37ea467f3ff9515fa164993d8638")
data = base64.b64decode("mNhw0fgyL8LE996nzxGlnmxi0d/O2SqbTGS+9kJK7Dg8QmsRrLiA31xZz1FyA6Y8PDut11tqwUnI8VSAmZVOELnhf5OKxu1y47EkBHHNJJvxGKcmTD5fn6tk6rqeYvzuj4at31YCq4W/6RFmIIZvMN8iGRTzD+EDYoCnHbSfLKDGsTv6tChAtoE/zd63RQHOmerbDv1knITpz1NkaJH4LQ==")
parser = argparse.ArgumentParser()
parser.add_argument("--key-file", type=Path)
args = parser.parse_args()
if args.key_file is None:
    print(key_locator)
else:
    key = bytes.fromhex(args.key_file.read_text(encoding="ascii"))
    decoder = Cipher(algorithms.AES(key), modes.CBC(iv)).decryptor()
    padded = decoder.update(data) + decoder.finalize()
    unpadder = padding.PKCS7(128).unpadder()
    config = (unpadder.update(padded) + unpadder.finalize()).decode("utf8")
    import os
    from pathlib import Path

    parent = os.environ.get("RE_FIXTURE_LAB")
    if parent:
        lab = Path(parent) / "case-11"
        lab.mkdir()
        import json
        cfg = json.loads(config)
        profile = lab / "session.ini"
        profile.write_text("session=LAB-SESSION-11", encoding="ascii")
        token = profile.read_text(encoding="ascii").split("=", 1)[1]
        (lab / "queue.json").write_text(json.dumps({"target": cfg["endpoint"], "session": token}), encoding="ascii")

    print(config)
